"""Deep agent template package."""
